from tkinter import *
import time
import os
from ftplib import FTP
from datetime import datetime
from tkinter import messagebox

root = Tk()
root.geometry("1280x780+0+0")
root.title("Yayoi ยาโยอิ")
root.configure(background='#bfebe0')

#===== ป้ายชื่อร้าน =====
Tops = Frame(root,width = 1600,height=50,bg = "#bfebe0",relief = SUNKEN)
Tops.pack(side=TOP)

fMainR = Frame(root,width= 440,height = 400, relief=RAISED)
fMainR.pack(side=RIGHT)

#===== รายการอาหาร =====
f1 = Frame(root,width = 600,height = 700,bg = '#bfebe0',relief = SUNKEN)
f1.pack(side=LEFT)
#===== คิดเงิน =====
f2 = Frame(root,width = 600,height = 700,bg = '#bfebe0',relief = SUNKEN)
f2.pack(side=TOP)

fReceipt = Frame(fMainR,width= 440,height = 450, bg = "#ffe9cc",bd=10, relief=RAISED)
fReceipt.pack(side=TOP)

fButton = Frame(fMainR,width= 440,height = 240,)
fButton.pack(side=BOTTOM)

#=============== Time ===============
localtime = time.asctime()

#=============== ป้ายชื่อร้าน ===============
lb1Info = Label(Tops,font= ('TH sarabun New',30,'bold'),
                text = "Yayoi Menu",fg="#000044",bg='#bfebe0',bd=10,anchor='w')
lb1Info.grid(row=0,column=0)
#=============== โชว์เวลาแบบที่เรียน ===============
lb1Info = Label(Tops,font= ('TH Sarabun New',12,'bold'),
                text=localtime,fg='#A0522D',bd= 10,anchor='w')
lb1Info.grid(row=1,column=0)

#=============== Define variable and Function ===============
text_Input = StringVar() #โชว์รายการอาหาร
Total = StringVar() #ราคารวม
Vat_price = StringVar() #ภาษี
Tax = StringVar() #ราคารวมภาษี
inputPrice = StringVar() #ป้อนเงิน
chang_money = StringVar() #เงินทอน
license_Plate = StringVar() #ป้ายทะเบียน
conFirm = StringVar() #ยืนยัน

# p = ""
# operator = ""

#===================== read text =====================
item = [] #เมนูอาหาร
itemPrice = [] #ราคาอาหาร

try:
    menuList = open("Menu.txt",'r',encoding="utf-8")
except IOError:
    print("Can not find file")
else:
    for line in menuList:
        foodItem, priceMenu = line.split()
        item.append(foodItem)
        itemPrice.append(priceMenu)
    menuList.close()

def btnClick(number, price):
    global text_Input
    global operator
    # global p
    # p = p + price + " + "
    p_menu.append(price)
    # operator = operator + "\n" + number + " + "

    if number == "หมูย่างกระทะร้อน":
        p1.append(number)
    if number == "แฮมเบอร์หมูกระทะร้อน":
        p2.append(number)
    if number == "มิกซ์โทจิ":
        p3.append(number)
    if number == "ปลาแซลม่อน":
        p4.append(number)
    if number == "ข้าวแกงกะหรี่เนื้อชีส":
        p5.append(number)
    if number == "แพนกาเซียสทรงเครื่อง":
        p6.append(number)
    if number == "ชิกกี้เบนโตะ":
        p7.append(number)
    if number == "ซาซิมิเดอลุกซ์เบนโตะ":
        p8.append(number)
    if number == "โซบะเย็น":
        p9.append(number)
    if number == "ยากิโซบะกระทะร้อน":
        p10.append(number)
    if number == "ชาเขียวเย็น":
        p11.append(number)
    if number == "น้ำแร่":
        p12.append(number)


totalPrice1 = 0
vatPrice = 0
chMoney = 0
Cost2 = 0

setZero = []  # เก็บรายการอาหารเวลากด
p_menu = []  # เก็บราคา
p1 = []  # หมูย่างกระทะร้อน
p2 = []  # แฮมเบอร์หมูกระทะร้อน
p3 = []  # มิกซ์โทจิ
p4 = []  # ปลาแซลม่อน
p5 = []  # ข้าวแกงกะหรี่เนื้อชีส
p6 = []  # แพนกาเซียสทรงเครื่อง
p7 = []  # ชิกกี้เบนโตะ
p8 = []  # ซาซิมิเดอลุกซ์เบนโตะ
p9 = []  # โซบะเย็น
p10 = []  # ยากิโซบะกระทะร้อน
p11 = []  # ชาเขียวเย็น
p12 = []  # น้ำแร่

#============== คิดเงิน ===================
def CalculateTotal():
    txtReceipt.delete("1.0", END)
    global totalPrice1, vatPrice, chMoney, Cost2
    totalPrice1 = 0
    vatPrice = 0
    chMoney = 0
    Cost2 = 0
    money = inputPrice.get()

    for i in p_menu:
        totalPrice1 = totalPrice1 + int(i)
        vatPrice = totalPrice1 * float(itemPrice[12]) / 100

    Total.set(str(totalPrice1) + " บาท ")
    Cost = str('%.2f' % vatPrice + " บาท ")
    Cost2 = str(float(totalPrice1) + float("%.2f" % vatPrice)) + " บาท "
    Tax.set(Cost2) #ราคารวมภาษี
    Vat_price.set(Cost)

    try:
        totalVat = float(totalPrice1) + float("%.2f" % vatPrice) #ราคารวมภาาษี
        if int(money) >= totalVat:
            chMoney = int(money) - totalVat
            chang_money.set(str("%.2f" % chMoney) + " บาท ")
    except ValueError:
        inputPrice.set("กรอกตัวเลขเท่านั้น")
        chang_money.set("ไม่มีเงินทอน")
    else:
        if int(money) < totalVat:
            inputPrice.set("จำนวนเงินไม่พอ")

    txtReceipt.insert(END, "----------------------- รายการอาหารที่สั่ง ----------------------- \n")
    txtReceipt.insert(END, "หมูย่างกระทะร้อน \t\t\t\t\t" + str(len(p1)) + "\n")
    txtReceipt.insert(END, "แฮมเบอร์หมูกระทะร้อน \t\t\t\t\t" + str(len(p2)) + "\n")
    txtReceipt.insert(END, "มิกซ์โทจิ \t\t\t\t\t" + str(len(p3)) + "\n")
    txtReceipt.insert(END, "ปลาแซลม่อน \t\t\t\t\t" + str(len(p4)) + "\n")
    txtReceipt.insert(END, "ข้าวแกงกะหรี่เนื้อชีส \t\t\t\t\t" + str(len(p5)) + "\n")
    txtReceipt.insert(END, "แพนกาเซียสทรงเครื่อง \t\t\t\t\t" + str(len(p6)) + "\n")
    txtReceipt.insert(END, "ชิกกี้เบนโตะ \t\t\t\t\t" + str(len(p7)) + "\n")
    txtReceipt.insert(END, "ซาซิมิเดอลุกซ์เบนโตะ \t\t\t\t\t" + str(len(p8)) + "\n")
    txtReceipt.insert(END, "โซบะเย็น \t\t\t\t\t" + str(len(p9)) + "\n")
    txtReceipt.insert(END, "ยากิโซบะกระทะร้อน \t\t\t\t\t" + str(len(p10)) + "\n")
    txtReceipt.insert(END, "ชาเขียวเย็น \t\t\t\t\t" + str(len(p11)) + "\n")
    txtReceipt.insert(END, "น้ำแร่ \t\t\t\t\t" + str(len(p12)) + "\n")
#================= ส่งไฟล์ FTP ================================
global totalList
def uploadFTP():
    priceTotal = str(int(totalPrice1) + int(vatPrice)) # ราคารวม

    global ftp
    try:
        input = open("account_arm.txt", encoding="utf-8")
    except IOError:
        print("Can not find file")
    else:
        ip, user, password = input.read().split(";")
        input.close()

        try:
            ftp = FTP(ip)
            ftp.login(user=user, passwd=password)
            ftp.encoding = 'utf-8'
        except:
            print("Invalid username or password")
        else:

            file = ftp.nlst()
            for f in file:
                if license_Plate.get() + ".txt" == f:
                    print(f)
                    filename = license_Plate.get() + ".txt" #โหลดไฟล์
                    localfile = open(filename, 'wb')
                    ftp.retrbinary('RETR ' + filename, localfile.write, 1024)

                    ftp.delete(filename) #ลบไฟล์หลังโหลด
                    localfile.close()

                    saveFile = open(license_Plate.get() + ".txt", 'a', encoding="utf-8") #เขียนราคาลงไฟล์ใหม่
                    saveFile.write(priceTotal)
                    messagebox.showinfo("Warning", "ดำเนินการเสร็จสิ้น")
                    saveFile.close()

                    filename2 = license_Plate.get() + ".txt"  # อัพไฟล์ใหม่
                    ftp.storbinary('STOR ' + filename2, open(filename2, 'rb'))
                    ftp.dir()
                    ftp.quit()
                if license_Plate.get() + ".txt" != f:
                    messagebox.showinfo("Warning", "ไม่พบหมายเลขทะเบียนรถ!!")
                    ftp.quit()

def Reset():
    global totalPrice1,  vatPrice, chMoney, Cost2, p1, p2,p3,p3,p4,p5,p6,p7,\
        p8,p9,p10,p11,p12,txtReceipt

    text_Input.set("")
    Total.set("")
    Vat_price.set("")
    Tax.set("")
    inputPrice.set("")
    chang_money.set("")
    license_Plate.set("")

    setZero.clear()
    p_menu.clear()
    totalPrice1 = 0
    vatPrice = 0
    chMoney = 0
    Cost2 = 0

    txtReceipt.delete("1.0", END)

    p1.clear()  # หมูย่างกระทะร้อน
    p2.clear()  # แฮมเบอร์หมูกระทะร้อน
    p3.clear()  # มิกซ์โทจิ
    p4.clear()  # ปลาแซลม่อน
    p5.clear()  # ข้าวแกงกะหรี่เนื้อชีส
    p6.clear()  # แพนกาเซียสทรงเครื่อง
    p7.clear()  # ชิกกี้เบนโตะ
    p8.clear()  # ซาซิมิเดอลุกซ์เบนโตะ
    p9.clear()  # โซบะเย็น
    p10.clear()  # ยากิโซบะกระทะร้อน
    p11.clear()  # ชาเขียวเย็น
    p12.clear()  # น้ำแร่

def qExit():
    root.destroy()

def update(file,amount):
    global ftp_server,usr,pw
    now = datetime.now()
    currenttime = now.strftime("%d%m%Y")
    ftp = FTP(ftp_server)
    ftp.login(user=usr,passwd=pw)
    ftp.encoding='utf-8'
    try:
        xx = ftp.nlst()
        data = file.split(".txt")[0] + " " + str(amount)+"\n"
        filename = currenttime + ".txt"
        if(filename in xx):
            localfile = open(filename,'wb')
            ftp.retrbinary('RETR '+filename,localfile.write,1024)
            localfile.close()
            test=open(filename,"r",encoding="utf-8")
            c = test.readlines()
            print(c)
            c.append(data)
            print(c)
            test.close()
            test=open(filename,"w",encoding="utf-8")
            test.write(''.join(c))
            test.close()
            file = open(filename,'rb')
            ftp.storbinary('STOR '+filename,file)
            file.close()
            xx = ftp.nlst()
            os.remove(filename)
            print(xx)
    except:
        print("")

#=============== ฝั่งขวา ===============
lb2Info = Label(fReceipt,font= ('TH Sarabun New',20,'bold'),
                text = "Your Order Yayoi",fg="#A0522D",bd=10,anchor='e')
lb2Info.grid(row=0,column=1)

#serVer = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
#                text = 'Server', fg='blue',bd= 10,anchor='w')
#serVer.grid(row=1,column=0)
#serVerReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'),bd=6,insertwidth=5,
#                justify='right',width=30)
#serVerReference.grid(row=1,column=1)

licensePlate = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
                text = 'ป้ายทะเบียน', fg='#000044',bg='#ffe9cc',bd=6,anchor='w')
licensePlate.grid(row=2,column=0,pady=3)
licensePlateReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'), bd=6,insertwidth=5,
                justify='right',width=30, textvariable=license_Plate)
licensePlateReference.grid(row=2,column=1,pady=5)


lblReceipt = Label(fReceipt,font=('TH Sarabun New',15,'bold'),
                   text="รายการอาหารที่สั่ง", bd=6,anchor='w',fg='#000044',bg='#ffe9cc')
lblReceipt.grid(row=3,column=0, sticky=W,padx=5)
# txtReceipt = Entry(fReceipt,font=('TH Sarabun New',13,'bold'), textvariable=text_Input,bd=6,insertwidth=5,
#                    justify='right',width=45)
# txtReceipt.grid(row=3,column=1)

txtReceipt = Text(fReceipt,font=('TH Sarabun New',11,'bold'), bd=4,width=45,height=15,bg="white")
txtReceipt.grid(row=3,column=1)

totalPrice = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
                text = 'ราคารวม', fg='#000044',bg='#ffe9cc',bd= 6,anchor='w')
totalPrice.grid(row=4,column=0,pady=5)
totalPriceReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'), textvariable=Total, bd=6,insertwidth=5,
                justify='right',width=30,)
totalPriceReference.grid(row=4,column=1,pady=5)

tax = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
                text = 'ภาษี', fg='#000044',bg='#ffe9cc',bd=6,anchor='w')
tax.grid(row=5,column=0,pady=5)
taxReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'),bd=6,insertwidth=5,
                justify='right',width=30, textvariable=Vat_price)
taxReference.grid(row=5,column=1,pady=5)

taxIncluded = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
                text = 'ราคารวมภาษี', fg='#000044',bg='#ffe9cc',bd=6,anchor='w')
taxIncluded.grid(row=6,column=0,pady=5)
taxIncludedReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'),textvariable=Tax,bd=6,insertwidth=5,
                justify='right',width=30)
taxIncludedReference.grid(row=6,column=1,pady=5)

receiveMoney = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
                text = 'รับเงิน',fg='#000044',bg='#ffe9cc',bd=6,anchor='w')
receiveMoney.grid(row=7,column=0,pady=5)
receiveMoneyReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'),bd=6,insertwidth=5,
                justify='right',width=30, textvariable=inputPrice)
receiveMoneyReference.grid(row=7,column=1,pady=5)

change = Label(fReceipt,font= ('TH Sarabun New',15,'bold'),
                text = 'ทอน',fg='#000044',bg='#ffe9cc',bd=6,anchor='w')
change.grid(row=8,column=0,pady=5)
changeReference = Entry(fReceipt,font= ('TH Sarabun New',13,'bold'),bd=6,insertwidth=5,
                justify='right',width=30, textvariable=chang_money)
changeReference.grid(row=8,column=1,pady=5)

btnTotal = Button(fButton,padx=16, fg="black",font=('TH Sarabun New',15,'bold'),bd=5,width=5,
                text="Total",bg="#6da9ff",command= lambda:CalculateTotal()).grid(row=0, column=0,padx=15,pady=5)

btnReset = Button(fButton,padx=16, fg="black",font=('TH Sarabun New',15,'bold'),bd=5,width=5,
                text="Reset",bg="#e4ff6d",command = lambda :Reset()).grid(row=0, column=1,padx=15,pady=5)

btnExit = Button(fButton,padx=16, fg="black",font=('TH Sarabun New',15,'bold'),bd=5,width=5,
                text="Exit",bg="#ff6d6f",command = lambda:qExit()).grid(row=0, column=2,padx=15,pady=5)

btnConfirm = Button(fButton,padx=16, fg="black",font=('TH Sarabun New',15,'bold'),bd=5,width=5,
                text="ยืนยัน",bg="#b8ff6d",command = lambda:uploadFTP()).grid(row=0, column=3,padx=15,pady=5)

#===== row 1 =====
photo1 = PhotoImage(file="5.png")
btn1 = Button(f1,text="1",image=photo1,
              command = lambda:btnClick(item[0], (itemPrice[0]))).grid(row=0,column=0,padx=(20,5))
lblMenu1 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[0], fg='#000044',bg='#bfebe0',bd=5, anchor='w')
lblMenu1.grid(row=1,column=0)

photo2 = PhotoImage(file="8.png")
btn2 = Button(f1, text="2", image=photo2,
              command = lambda:btnClick(item[1], (itemPrice[1]))).grid(row=0,column=1,padx=5)
lb1Menu2 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[1], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu2.grid(row=1,column=1)

photo3 = PhotoImage(file="7.png")
btn3 = Button(f1, text="3", image=photo3,
              command = lambda:btnClick(item[2], (itemPrice[2]))).grid(row=0,column=2,padx=5)
lb1Menu3 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[2], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu3.grid(row=1,column=2)

photo4 = PhotoImage(file="6.png")
btn4 = Button(f1, text="4", image=photo4,
              command = lambda:btnClick(item[3], (itemPrice[3]))).grid(row=0,column=3,padx=5)
lb1Menu4 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[3], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu4.grid(row=1,column=3)

#===== row 2 =====
photo5 = PhotoImage(file="9.png")
btn5 = Button(f1, text="5", image=photo5,
              command = lambda:btnClick(item[4], (itemPrice[4]))).grid(row=2,column=0,padx=5)
lb1Menu5 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[4], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu5.grid(row=3,column=0)

photo6 = PhotoImage(file="10.png")
btn6 = Button(f1, text="D6", image=photo6,
              command = lambda:btnClick(item[5], (itemPrice[5]))).grid(row=2,column=1,padx=5)
lb1Menu6 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[5], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu6.grid(row=3,column=1)

photo7 = PhotoImage(file="11.png")
btn7 = Button(f1, text="7", image=photo7,
              command = lambda:btnClick(item[6], (itemPrice[6]))).grid(row=2,column=2,padx=5)
lb1Menu7 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[6], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu7.grid(row=3,column=2)

photo8 = PhotoImage(file="12.png")
btn8 = Button(f1, text="8", image=photo8,
              command = lambda:btnClick(item[7], (itemPrice[7]))).grid(row=2,column=3,padx=5)
lb1Menu8 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[7], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu8.grid(row=3,column=3)

#===== row 3 =====
photo9 = PhotoImage(file="3.png")
btn9 = Button(f1, text="9", image=photo9,
              command = lambda:btnClick(item[8], (itemPrice[8]))).grid(row=4,column=0,padx=5)
lb1Menu9 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[8], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu9.grid(row=5,column=0)

photo10 = PhotoImage(file="4.png")
btn10 = Button(f1, text="10", image=photo10,
               command = lambda:btnClick(item[9], (itemPrice[9]))).grid(row=4,column=1,padx=5)
lb1Menu10 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[9], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu10.grid(row=5,column=1)

photo11 = PhotoImage(file="2.png")
btn11 = Button(f1, text="11", image=photo11,
               command = lambda:btnClick(item[10], (itemPrice[10]))).grid(row=4,column=2,padx=5)
lb1Menu11 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[10], fg='#000044',bg='#bfebe0',bd=5,anchor='w')
lb1Menu11.grid(row=5,column=2)

photo12 = PhotoImage(file="1.png")
btn12 = Button(f1, text="12", image=photo12,
               command = lambda:btnClick(item[11], (itemPrice[11]))).grid(row=4,column=3,padx=5)
lb1Menu12 = Label(f1,font=('TH Sarabun New',14,'bold'),text= item[11],bd=5, fg='#000044',bg='#bfebe0',anchor='w')
lb1Menu12.grid(row=5,column=3)

root.mainloop()