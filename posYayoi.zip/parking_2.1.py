from tkinter import *
import random
import time
import os
from datetime import datetime
from ftplib import FTP
import smtplib
from tkinter import messagebox
from email.mime.text import MIMEText

root = Tk()
root.geometry("1130x680+0+0")
root.title("Parking Iot")
root.configure(background='lemonchiffon2')



#===================Frame==================
Tops = Frame(root,width = 1000,height=50,bg = "white",relief = SUNKEN)
Tops.pack(side=TOP)

f1 = Frame(root,width = 800,height = 700,relief = SUNKEN,bg ="lemonchiffon2").pack()
#----right frame-----------
fMainR = Frame(root,width= 350,height = 200, bd=10, relief=RIDGE,bg="lemonchiffon2")
fMainR.place(x=690,y=220)
fTotal = Frame(fMainR,width= 350,height = 200,bd=12, relief="raise")
fTotal.pack(side=TOP)

#=====================Top=================

lb1Info = Label(Tops,font = ('Berlin Sans FB Demi',55,'bold'),relief=RIDGE,width=10,
        text=" Parking Iot",fg= "goldenrod",bg= "navy",anchor='w')
lb1Info.grid(row=0,column=0)

#================ Time ===================
localtime = time.asctime(time.localtime(time.time()))

lb1Info = Label(Tops,font= ('Berlin Sans FB Demi',20,'bold'),
                text=localtime,fg='red',bd= 10,bg="white",anchor='w')
lb1Info.grid(row=2,column=0)

#=============Define variable and Function =========
text_Input = StringVar()
Total = StringVar()
Send =StringVar()
Enter = StringVar()
checkin =StringVar()
checkout = StringVar()

#==================  FTP  ===========================
ftp_server = "localhost"
usr = "FTP"
pw = "Worler55"

def update(file,mall,amount,time1,time2):
    global ftp_server,usr,pw
    now = datetime.now()
    time1 = time1.replace(':', '.')
    time2 = time2.replace(':', '.')
    current_time = now.strftime("%d_%m_%Y")
    ftp = FTP(ftp_server)
    ftp.login(user=usr,passwd=pw)
    ftp.encoding='utf-8'
    try:
        # file='กข1234.txt' => ['กข1234']
        xx = ftp.nlst()
        data = file.split(".txt")[0] +"\t"+str(amount)+'\t'+str(mall)+"\t"+str(time1)+"\t"+str(time2)+"\n" #ชื่อไฟล์ที่เก็บ ex data = 'กข2345 50\n'
        filename = current_time+".txt"
        #เชคว่ามีไฟล์ ในFTPยัง if = มี
        if(filename in xx):
            #โหลดไฟล์จาก FTP
            localfile = open(filename,'wb')
            ftp.retrbinary('RETR '+filename,localfile.write,1024)
            localfile.close()
            #เปิดไฟล์ที่โหลด
            test=open(filename,"r",encoding="utf-8")
            c = test.readlines()
            #c = ['กข1234 0\n','กข1234 30\n','กข1234 60\n']
            c.append(data)
            #c = ['กข1234 0\n','กข1234 30\n','กข1234 60\n','กข2345 50\n']
            test.close()
            test=open(filename,"w",encoding="utf-8")
            test.write(''.join(c))
            test.close()
            file = open(filename,'rb')
            ftp.storbinary('STOR '+filename,file)
            file.close()
            xx = ftp.nlst()
            os.remove(filename)
            print(xx)

        else:
            test=open(filename,"w",encoding="utf-8")
            test.write(data)
            test.close()
            file = open(filename,'rb')
            ftp.storbinary('STOR '+filename,file)
            file.close()
            xx = ftp.nlst()
            print(xx)
    except:
        print("error")
    finally:
        ftp.close()

def Upload(name):
    global ftp_server,usr,pw, ftp
    result = 0
    try:
        ftp = FTP(ftp_server)
        ftp.login(user=usr,passwd=pw)
        ftp.encoding='utf-8'
        xx = ftp.nlst()
        if(name in xx):
            result = 0 #มีรถอยู่เเล้ว
        else:
            file = open(name,'rb')
            ftp.storbinary('STOR '+name,file)
            xx = ftp.nlst()
            print(xx)
            result = 1
    except:
        print("")
    finally:
        ftp.close()
        return result

def Download(name):
    global ftp_server,usr,pw, ftp
    result = 0
    try:
        ftp = FTP(ftp_server)
        ftp.login(user=usr,passwd=pw)
        ftp.encoding='utf-8'
        xx = ftp.nlst()
        if( name in xx):
            localfile = open(name,'wb')
            ftp.retrbinary('RETR '+name,localfile.write,1024)
            localfile.close()
            ftp.delete(name)
            result = 1

        else:
            result = 0
    except:
        print("")
    finally:
        ftp.close()
        return result



def qExit():
    root.destroy()
def Reset():
    rand.set("")
    Shopping.set("")
    TotalTime.set("")
    Money.set("")
    txtTotal.delete("1.0",END)
def retrieve_input(): #Entry
    inputValue=txtReference.get()
    print(inputValue)
    name = inputValue + ".txt"
    if(' ' in  name):
        name = name.split()
        name = name[0]+name[1]
    now = datetime.now()
    current_time = now.strftime("%d/%m/%Y %H:%M:%S")
    test=open(name,"w",encoding="utf-8")
    test.write("in "+str(current_time)+"\n")
    test.close()
    result = Upload(name)
    os.remove(name)
    if(inputValue==""):
        messagebox.showinfo("Warning", "กรุณากรอกทะเบียนรถก่อน!!")
    elif(result == 1):
        messagebox.showinfo("Warning", "ลงทะเบียนรถเรียนร้อย!!")
    else:
        messagebox.showinfo("Warning", "ทะเบียนรถนี้อยู่ในที่จอดรถแล้ว กรุณาตรวจสอบอีกครั้ง!!")

def Send():
    global ftp_server,usr,pw
    ftp = FTP(ftp_server)
    ftp.login(user=usr,passwd=pw)
    ftp.encoding='utf-8'
    try:
        Input = open("SMTP_Account.txt")
        account,password,receivers = Input.read().split(";")
        account = account.strip()
        password = password.strip()
        receivers = receivers.strip()
        Input.close()
        print(account,password,receivers)
        now = datetime.now()
        current_time = now.strftime("%d_%m_%Y")
        filename = current_time+".txt"
        localfile = open(filename,'wb')
        ftp.retrbinary('RETR '+filename,localfile.write,1024)
        localfile.close()
        f=open(filename,"r",encoding="utf-8")
        c = f.readlines()
        c = [int(i.split('\t')[1]) for i in c]
        print(c,sum(c))
        total=sum(c)
        f.close()
        f=open(filename,"r",encoding="utf-8")
        al = f.readlines()
        f.close()
        #print(al)
        msal = ''.join(al)
        ftp.close()
        os.remove(filename)
        
        try:
            server = smtplib.SMTP('smtp.gmail.com',587,timeout=120)
            server.starttls()
            server.login(account,password)
            msg = 'ป้ายทะเบียน\tค่าจอดรถ\tค่าใช้จ่ายในห้าง\tเวลาเข้า\tเวลาออก\n'
            msg += str(msal)
            msg += "ยอดรวมวันที่ "+ str(current_time)+ " การรับชำระค่าจอดรถ "+str(total)+" บาท"
            
            #print(len(msg))
            print(msg)
            msg=msg.encode('utf-8').strip()
            server.sendmail(account,receivers,msg)
            print("Send Mail Successfully")
            messagebox.showinfo("Warning", "ทำการปิดยอดสำเร็จ!!")
            server.quit()
        except:
            print("server not found")
    except:
        print("file not found")

def out():
    if(1):
        inputValue=txtReference.get()
        if(inputValue==""):
            messagebox.showinfo("Warning", "กรุณากรอกทะเบียนรถก่อน!!")
        else:
            name = inputValue + ".txt"
            if(' ' in  name):
                name = name.split()
                name = name[0]+name[1]
    
            result = Download(name)
            
            if(result == 1):
                test=open(name,"r",encoding="utf-8")
                c1 = test.readlines()
                print(len(c1))
                if(len(c1) == 1):
                    c2 = 0
                else:
                    c2 = int(c1[1]) #บันทัดที่1 ราคา
                c1 = c1[0].split()
                print(c1,c2)
                start = datetime.strptime(c1[1]+" "+c1[2], '%d/%m/%Y %H:%M:%S')
                strst = str(start).split()[1]
                now = datetime.now()
                current_time = now.strftime("%d/%m/%Y %H:%M:%S")
                end = datetime.strptime(current_time, '%d/%m/%Y %H:%M:%S')
                strend = str(end).split()[1]
                print(strend)
                time = end-start
                time = str(time) # "00:49:37"
                time = [int(i) for i in time.split(":")] # ["00","49","37"] => [00,49,37]
                print(time)
                payinmall=c2 #เงินที่ใช้จ่าย
                total=0
    
                hours = time[0]
                minute = time[1]
                if(minute > 30):
                    hours += 1
                    minute = 0
    
                if(payinmall >1000):
                    total = 0
    
                elif(payinmall >=100 and payinmall<1000 ):
                    if(hours>1):
                        hours-=1
                        total = hours*30
                    else:
                        total = 0
    
                elif (payinmall >= 0 and payinmall<100):
                    total = hours * 30
                else:
                    messagebox.showinfo("Warning", "กรุณาตรวจสอบอีกครั้ง")
    
                print(time[0])
                test.close()
                os.remove(name)
                update(name,payinmall,total,strst,strend)
                messagebox.showinfo("Warning", "ดำเนินการสำเร็จ!!")
    
                txtTotal.delete("1.0",END)
                txtTotal.insert(END,'\t' + DateofDay.get() + "\n")
                #txtTotal.insert(END,'\tItems\t\t'+ 'Cost \n\n')
                txtTotal.insert(END,'\nจำนวนเงินที่ SHOPPING : \t\t'+str(payinmall) + '\n\n')
                txtTotal.insert(END,'จำนวนเงิน : \t\t'+ str(total) + '\n')
            
            else:
                messagebox.showinfo("Warning", "ไม่มีหมายเลขทะเบียนนี้ กรุณาตรวจสอบอีกครั้ง!!")

    else:
        print("Check file")


#============================= Parking Info 1 ======================
rand = StringVar()
Shopping = StringVar()
TotalTime = StringVar()
Money =StringVar()
DateofDay = StringVar()
DateofDay.set(time.strftime("%d/%m/%Y"))


lblReference = Label(f1,font=('Berlin Sans FB Demi',30,'bold'),text="Car registration",bg="lemonchiffon2")
lblReference.place(x=50,y=200)
txtReference= Entry(f1,font=('FreesiaUPC',25,'bold'),textvariable=rand,insertwidth=4, relief=RIDGE,
bg="white",justify= 'right')
txtReference.place(x=225,y=300)

lblTotal = Label(fTotal,font=('Berlin Sans FB Demi',12,'bold'), text="Total", bd=2,anchor='w')
lblTotal.grid(row=0,column=0, sticky=W)
txtTotal = Text(fTotal,font=('FreesiaUPC',20,'bold'), bd=8,width=30,height=7,bg="khaki2")
txtTotal.grid(row=1,column=0)

#=====================Button=================
btnEnter=Button(f1,padx=5,pady=3,bd=2,fg="black",font=('Berlin Sans FB Demi',16,'bold'),width=5,
                text="Entry",bg="#6da9ff",command=lambda: retrieve_input()).place(x=190,y=400)
btnOut=Button(f1,padx=5,pady=3,bd=2,fg="black",font=('Berlin Sans FB Demi',16,'bold'),width=5,
                text="Out",bg="coral2",command=lambda: out()).place(x=460,y=400)

btnReset=Button(f1,padx=6,pady=4,bd=8,fg="black",font=('Berlin Sans FB Demi',18,'bold'),width=5,
                text="Reset",bg="#e4ff6d",command=Reset).place(x=30,y=580)

btnExit=Button(f1,padx=6,pady=4,bd=8,fg="black",font=('Berlin Sans FB Demi',18,'bold'),width=5,
               text="Exit",bg="red",command=qExit).place(x=200,y=580)

btnSend=Button(f1,padx=6,pady=4,bd=10,fg="black",font=('Berlin Sans FB Demi',20,'bold'),width=7,
                text="SUM",bg="chocolate1",command=lambda:Send()).place(x=960,y=590)



root.mainloop()
